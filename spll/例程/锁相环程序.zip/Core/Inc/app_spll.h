#ifndef __APP_SPLL_H__
#define __APP_SPLL_H__
#include "spll_1ph_sogi.h"
#include "spll_1ph_sogi_fll.h"
extern void app_spll_run(SPLL_1PH_SOGI *spll_obj, float acValue);
extern void app_spll_init();

extern SPLL_1PH_SOGI_FLL TTPLPFC_spll3;
#endif
