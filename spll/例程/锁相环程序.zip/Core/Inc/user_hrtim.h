#ifndef __USER_HRTIM_H__
#define __USER_HRTIM_H__
#include "stdint.h"
typedef struct
{
	float pwm1duty;
	float pwm2duty;
	float pwm3duty;
	float pwm4duty;
	float pwmFreq;
	float deadtime_ns;
	float pwm1Phase_deg;
	float pwm2Phase_deg;
	float pwm3Phase_deg;
	float pwm4Phase_deg;
} pwmParaTypeDef;

extern void USER_HRTIM_pwmPara_Init(pwmParaTypeDef *sptr,
							  const float pwm1duty,
							  const float pwm2duty,
							  const float pwm3duty,
							  const float pwm4duty,
							  const float pwmFreq,
							  const float deadtime_ns,
							  const float pwm1Phase_deg,
							  const float pwm2Phase_deg,
							  const float pwm3Phase_deg,
							  const float pwm4Phase_deg);
extern void USER_HRPWM_START();
extern pwmParaTypeDef myPwmStr;
extern void USER_HRTIM_pwmParameterUpdate(pwmParaTypeDef *pwmParaStr);

#endif
