#ifndef __APP_DAC_H__
#define __APP_DAC_H__

typedef struct
{
	uint16_t dacval;
}DAC_DATA_STR;

extern DAC_DATA_STR dac1_data;
#endif
