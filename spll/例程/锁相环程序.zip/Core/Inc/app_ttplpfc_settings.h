#ifndef __APP_TTPLPFC_SETTINGS_H__
#define __APP_TTPLPFC_SETTINGS_H__
/*一些固定的物理参数*/
#define TTPLPFC_AC_FREQ 50                  // 电网频率
#define TTPLPFC_CONTROL_ISR_FREQUENCY 10e3 // 控制中断频率
#define PWM_FREQ 10e3                      // PWM频率
#endif
