#ifndef __USER_USART_H__
#define __USER_USART_H__
#include "stdint.h"
#include "usart.h"
extern uint8_t uart1tx_buf[80];
extern uint8_t uart1rx_buf[10];
#endif
