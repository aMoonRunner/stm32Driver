/*===================================================
作者: jhshe
版本: 0.0
邮箱: jh_she@qq.com
创建时间: 2023/11/29 星期三
说明：基于二阶广义积分器的可变频率的单相锁相环头文件
===================================================*/


#ifndef SPLL_1PH_SOGI_FLL_H
#define SPLL_1PH_SOGI_FLL_H

typedef struct
{
    float osg_b0;
    float osg_b2;
    float osg_a1;
    float osg_a2;
    float osg_qb0;
    float osg_qb1;
    float osg_qb2;
} SPLL_1PH_SOGI_FLL_OSG_COEFF;

typedef struct
{
    float b1;
    float b0;
} SPLL_1PH_SOGI_FLL_LPF_COEFF;

typedef struct
{
    float u[3];                            //!< AC input data buffer
    float osg_u[3];                        //!< Orthogonal signal generator data buffer
    float osg_qu[3];                       //!< Orthogonal signal generator quadrature data buffer
    float u_Q[2];                          //!< Q-axis component
    float u_D[2];                          //!< D-axis component
    float ylf[2];                          //!< Loop filter data storage
    float fo;                              //!< Output frequency of PLL(Hz)
    float fn;                              //!< Nominal frequency (Hz)
    float wc;                              //!< Center (Nominal) frequency in radians
    float theta;                           //!< Angle output (0-2*pi)
    float cosine;                          //!< Cosine value of the PLL angle
    float sine;                            //!< Sine value of the PLL angle
    float delta_t;                         //!< Inverse of the ISR rate at which module is called
    float ef2;                             //!< FLL parameter
    float x3[2];                           //!< FLL data storage
    float w_dash;                          //!< Output frequency of PLL(radians)
    float gamma;                           //!< Gamma parameter for FLL
    float k;                               //!< K parameter for FLL
    SPLL_1PH_SOGI_FLL_OSG_COEFF osg_coeff; //!< Orthogonal signal generator coefficient
    SPLL_1PH_SOGI_FLL_LPF_COEFF lpf_coeff; //!< Loop filter coeffcient structure
} SPLL_1PH_SOGI_FLL;

extern void SPLL_1PH_SOGI_FLL_reset(SPLL_1PH_SOGI_FLL *spll_obj);
extern void SPLL_1PH_SOGI_FLL_config(SPLL_1PH_SOGI_FLL *spll_obj, float acFreq, float isrFrequency, float lpf_b0, float lpf_b1, float k, float gamma);
extern void SPLL_1PH_SOGI_FLL_run(SPLL_1PH_SOGI_FLL *spll_obj, float acValue);

#endif
