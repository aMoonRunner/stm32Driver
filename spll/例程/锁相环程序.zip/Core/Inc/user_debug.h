#ifndef __USER_DEBUG_H__
#define __USER_DEBUG_H__
#include "user_usart.h"
extern void USER_DEBUG_sendDataToComputer(void);
extern void USER_DEBUG_checkOrderFromComputer(void);
#endif
