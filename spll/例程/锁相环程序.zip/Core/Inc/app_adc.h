#ifndef __APP_ADC_H__
#define __APP_ADC_H__

#define ADC1_CHANNEL_CNT 4 	//采样通道数
#define ADC_PU_SCALE_FACTOR      (float)(0.000244140625)//1/4096

typedef struct
{
	uint16_t channelCNT;				//adc采样通道数
	float scaleFactor;					//adc的折算系数（1/4096）
	uint16_t adcval[ADC1_CHANNEL_CNT];	//adc的读数0-4096
	float volts[ADC1_CHANNEL_CNT];		//adc的真实电压0-3.3V
	float realvolts[ADC1_CHANNEL_CNT];
}ADC_DATA_STR;

extern ADC_DATA_STR adc1_data;
extern ADC_DATA_STR adc2_data;
extern void app_adc_init(ADC_DATA_STR *adc_data_str);
extern void app_adc_readOnce(ADC_DATA_STR *adc_data_str);
#endif
