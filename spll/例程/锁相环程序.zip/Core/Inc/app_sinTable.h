#ifndef __APP_SINTABLE_H__
#define __APP_SINTABLE_H__
#include "stdint.h"

#define SINTABLE_LENGTH 200
#define COSTABLE_LENGTH 200
extern float COSTABLE[COSTABLE_LENGTH];
extern float SINTABLE[SINTABLE_LENGTH];

extern void app_sinTable_init();
extern float app_sineTable_getsinValue(float x);
extern float app_sineTable_getcosValue(float x);
#endif
