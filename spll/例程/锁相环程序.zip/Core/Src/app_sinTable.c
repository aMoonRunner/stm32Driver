#include "app_sinTable.h"
#include "stdint.h"
#include "math.h"

float SINTABLE[SINTABLE_LENGTH] = {0};
float COSTABLE[COSTABLE_LENGTH] = {0};

void app_sinTable_init()
{
    uint32_t i = 0;
    for (i = 0; i < SINTABLE_LENGTH; i++)
    {
        SINTABLE[i] = sin(2 * 3.14159265 * ((float)i / (float)SINTABLE_LENGTH));
    }
    for (i = 0; i < COSTABLE_LENGTH; i++)
    {
        COSTABLE[i] = cos(2 * 3.14159265 * ((float)i / (float)COSTABLE_LENGTH));
    }
}

/*非常简陋的查表法正弦函数*/
float app_sineTable_getsinValue(float x)
{
//    return SINTABLE[(uint32_t)(fmod(x, 2 * 3.14159) / (2 * 3.14159) * SINTABLE_LENGTH)];
//    return SINTABLE[(uint32_t)(x / (2 * 3.14159) * SINTABLE_LENGTH)];
    return SINTABLE[(uint32_t)(x *31.832)];
}

/*非常简陋的查表法余弦函数*/
float app_sineTable_getcosValue(float x)
{
//    return COSTABLE[(uint32_t)(fmod(x, 2 * 3.14159) / (2 * 3.14159) * SINTABLE_LENGTH)];
    return COSTABLE[(uint32_t)(x *31.832)];
}
