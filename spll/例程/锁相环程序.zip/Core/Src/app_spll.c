#include "app_spll.h"
#include "app_ttplpfc_settings.h"
#include "spll_1ph_sogi.h"
#include "spll_1ph_sogi_fll.h"

SPLL_1PH_SOGI_FLL TTPLPFC_spll3;
float TTPLPFC_ac_vol_sensed_pu;

void app_spll_init()
{
	SPLL_1PH_SOGI_FLL_reset(&TTPLPFC_spll3);
	SPLL_1PH_SOGI_FLL_config(&TTPLPFC_spll3, TTPLPFC_AC_FREQ, TTPLPFC_CONTROL_ISR_FREQUENCY, (float)(222.2862), (float)(-222.034), (float)0.5, (float)20000);
	SPLL_1PH_SOGI_reset(&TTPLPFC_spll1);
	SPLL_1PH_SOGI_config(&TTPLPFC_spll1, TTPLPFC_AC_FREQ, TTPLPFC_CONTROL_ISR_FREQUENCY, (float)(222.2862), (float)(-222.034));
}

void app_spll_run(SPLL_1PH_SOGI *spll_obj, float acValue)
{
	SPLL_1PH_SOGI_run(spll_obj, acValue);
}
