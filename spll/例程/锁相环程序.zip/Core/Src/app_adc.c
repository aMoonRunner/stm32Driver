#include "adc.h"
#include "app_adc.h"
#include "stdint.h"

uint16_t adc1_val_buf[ADC1_CHANNEL_CNT];

ADC_DATA_STR adc1_data = {0};
ADC_DATA_STR adc2_data = {0};


void app_adc_init(ADC_DATA_STR *adc_data_str)
{
    adc_data_str->scaleFactor = (float) 3.3 * (float)(0.000244140625);
    adc_data_str->channelCNT = 4;
}

void app_adc_readOnce(ADC_DATA_STR *adc_data_str)
{
    uint16_t i = 0;
    for (i = 0; i < adc_data_str->channelCNT; i++)
    {
        adc_data_str->volts[i] = adc_data_str->adcval[i] * adc_data_str->scaleFactor;
    }
    adc_data_str->realvolts[0]=adc_data_str->volts[0]-1.65;
}
