#include "user_debug.h"
#include <stdio.h>
#include "user_usart.h"
#include "app_spll.h"
void USER_DEBUG_checkOrderFromComputer(void)
{
}

void USER_DEBUG_sendDataToComputer(void)
{

}
