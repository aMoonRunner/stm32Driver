#include "user_hrtim.h"
#include "main.h"
#include "hrtim.h"
#include "stm32f3xx_hal.h"
#include "stm32f3xx_hal_hrtim.h"

HRTIM_CompareCfgTypeDef user_pCompareCfg = {0};
HRTIM_TimeBaseCfgTypeDef user_pTimeBaseCfg = {0};

//void USER_HRTIM_DutySet(HRTIM_HandleTypeDef *hhrtim, uint32_t TimerIdx, float duty)
//{
//	static uint32_t temp_pwmFrqRegValue = 0;
//	temp_pwmFrqRegValue=hhrtim->Instance->sTimerxRegs[TimerIdx].PERxR
//
//	static float temp_duty = 0;
//	temp_duty = duty;
//
//	user_pCompareCfg.CompareValue = temp_pwmFrqRegValue * (0.5 - 0.5 * temp_duty);
//	user_pCompareCfg.AutoDelayedMode = HRTIM_AUTODELAYEDMODE_REGULAR;
//	user_pCompareCfg.AutoDelayedTimeout = 0x0000;
//	HAL_HRTIM_WaveformCompareConfig(&hhrtim, TimerIdx, HRTIM_COMPAREUNIT_2, &user_pCompareCfg);
//
//	user_pCompareCfg.CompareValue = temp_pwmFrqRegValue * (0.5 + 0.5 * temp_duty);
//	HAL_HRTIM_WaveformCompareConfig(&hhrtim, TimerIdx, HRTIM_COMPAREUNIT_3, &user_pCompareCfg);
//}
//
//void USER_HRTIM_pwmParameterUpdate(pwmParaTypeDef *pwmParaStr)
//{
//	user_pTimeBaseCfg.Period = f_hrtim / pwmParaStr->pwmFreq;
//	user_pTimeBaseCfg.RepetitionCounter = 0;
//	user_pTimeBaseCfg.PrescalerRatio = HRTIM_PRESCALERRATIO_MUL32;
//	user_pTimeBaseCfg.Mode = HRTIM_MODE_CONTINUOUS;
//	HAL_HRTIM_TimeBaseConfig(&hhrtim1, HRTIM_TIMERINDEX_MASTER, &user_pTimeBaseCfg);
//
//	HAL_HRTIM_TimeBaseConfig(&hhrtim1, HRTIM_TIMERINDEX_TIMER_A, &user_pTimeBaseCfg);
//	// 变频之后，想要不变占空比，需要重新设置比较器的值
//	USER_HRTIM_DutySet(HRTIM_TIMERINDEX_TIMER_A, pwmParaStr->pwm1duty);
//	HAL_HRTIM_TimeBaseConfig(&hhrtim1, HRTIM_TIMERINDEX_TIMER_B, &user_pTimeBaseCfg);
//
//	USER_HRTIM_DutySet(HRTIM_TIMERINDEX_TIMER_B, pwmParaStr->pwm2duty);
//
//	HAL_HRTIM_TimeBaseConfig(&hhrtim1, HRTIM_TIMERINDEX_TIMER_C, &user_pTimeBaseCfg);
//
//	USER_HRTIM_DutySet(HRTIM_TIMERINDEX_TIMER_C, pwmParaStr->pwm3duty);
//	HAL_HRTIM_TimeBaseConfig(&hhrtim1, HRTIM_TIMERINDEX_TIMER_D, &user_pTimeBaseCfg);
//
//	USER_HRTIM_DutySet(HRTIM_TIMERINDEX_TIMER_D, pwmParaStr->pwm4duty);
//
//	user_pCompareCfg.CompareValue = hhrtim1.Instance->sMasterRegs.MPER * pwmParaStr->pwm1Phase_deg / 360;
//	HAL_HRTIM_WaveformCompareConfig(&hhrtim1, HRTIM_TIMERINDEX_MASTER, HRTIM_COMPAREUNIT_1, &user_pCompareCfg);
//
//	user_pCompareCfg.CompareValue = hhrtim1.Instance->sMasterRegs.MPER * pwmParaStr->pwm2Phase_deg / 360;
//	HAL_HRTIM_WaveformCompareConfig(&hhrtim1, HRTIM_TIMERINDEX_MASTER, HRTIM_COMPAREUNIT_2, &user_pCompareCfg);
//
//	user_pCompareCfg.CompareValue = hhrtim1.Instance->sMasterRegs.MPER * pwmParaStr->pwm3Phase_deg / 360;
//	HAL_HRTIM_WaveformCompareConfig(&hhrtim1, HRTIM_TIMERINDEX_MASTER, HRTIM_COMPAREUNIT_3, &user_pCompareCfg);
//
//	user_pCompareCfg.CompareValue = hhrtim1.Instance->sMasterRegs.MPER * pwmParaStr->pwm4Phase_deg / 360;
//	HAL_HRTIM_WaveformCompareConfig(&hhrtim1, HRTIM_TIMERINDEX_MASTER, HRTIM_COMPAREUNIT_4, &user_pCompareCfg);
//}
//
//pwmParaTypeDef myPwmStr;
//
//void USER_HRTIM_pwmPara_Init(pwmParaTypeDef *sptr,
//							 const float pwm1duty,
//							 const float pwm2duty,
//							 const float pwm3duty,
//							 const float pwm4duty,
//							 const float pwmFreq,
//							 const float deadtime_ns,
//							 const float pwm1Phase_deg,
//							 const float pwm2Phase_deg,
//							 const float pwm3Phase_deg,
//							 const float pwm4Phase_deg)
//{
//	sptr->pwm1duty = pwm1duty;
//	sptr->pwm2duty = pwm2duty;
//	sptr->pwm3duty = pwm3duty;
//	sptr->pwm4duty = pwm4duty;
//	sptr->pwmFreq = pwmFreq;
//	sptr->deadtime_ns = deadtime_ns;
//	sptr->pwm1Phase_deg = pwm1Phase_deg;
//	sptr->pwm2Phase_deg = pwm2Phase_deg;
//	sptr->pwm3Phase_deg = pwm3Phase_deg;
//	sptr->pwm4Phase_deg = pwm4Phase_deg;
//}
//
//void USER_HRPWM_START(void)
//{
//	HAL_HRTIM_WaveformOutputStart(&hhrtim1, HRTIM_OUTPUT_TA1 | HRTIM_OUTPUT_TA2);
//	HAL_HRTIM_WaveformCountStart(&hhrtim1, HRTIM_TIMERID_TIMER_A);
//	HAL_HRTIM_WaveformOutputStart(&hhrtim1, HRTIM_OUTPUT_TB1 | HRTIM_OUTPUT_TB2);
//	HAL_HRTIM_WaveformCountStart(&hhrtim1, HRTIM_TIMERID_TIMER_B);
//	HAL_HRTIM_WaveformOutputStart(&hhrtim1, HRTIM_OUTPUT_TC1 | HRTIM_OUTPUT_TC2);
//	HAL_HRTIM_WaveformCountStart(&hhrtim1, HRTIM_TIMERID_TIMER_C);
//	HAL_HRTIM_WaveformOutputStart(&hhrtim1, HRTIM_OUTPUT_TD1 | HRTIM_OUTPUT_TD2);
//	HAL_HRTIM_WaveformCountStart(&hhrtim1, HRTIM_TIMERID_TIMER_D);
//
//	HAL_HRTIM_WaveformCountStart(&hhrtim1, HRTIM_TIMERID_MASTER);
//
//	USER_HRTIM_pwmPara_Init(&myPwmStr, 0.5, 0.5, 0.5, 0.5, 120e3, 200, 0, 120, 240, 270);
//}
