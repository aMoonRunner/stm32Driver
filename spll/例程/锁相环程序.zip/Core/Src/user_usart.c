#include "user_usart.h"

uint8_t uart1tx_buf[80];
uint8_t uart1rx_buf[10];

int uart1rx_counter = 0;

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    if (huart == &huart1)
    {
        uart1rx_counter++;

        if (uart1rx_counter >= 1000)
        {
            uart1rx_counter = 0;
        }
    }
}
void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart)
{
    if (huart == &huart1)
    {

    }
}
